using System;
using System.Collections.Generic;
using CommunityToolkit.Mvvm;
using CommunityToolkit.Mvvm.ComponentModel;

namespace mvvm.Model
{  
    public partial class Test
    {
        public int? Major; //public int Major will be created automatically
        public int? Minor;
    }
    
    [ObservableObject]
    public partial class TreeNodeData
    {
        [ObservableProperty]
        private string? nodeName;

        [ObservableProperty]
        private bool isTop;

        [ObservableProperty]
        private bool isSelected;

        [ObservableProperty]
        private IList<TreeNodeData>? childNodes;
    }
}