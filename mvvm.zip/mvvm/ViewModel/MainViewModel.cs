using System;
using System.Windows;
using System.Linq;
using System.ComponentModel;
using System.Collections.Generic;
using mvvm.Model;
using CommunityToolkit.Mvvm;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;
using CommunityToolkit.Mvvm.Input;

namespace mvvm.ViewModel
{
    public partial class MainViewModel
    {
        //Flat Test data list
        private List<Test> TestDataList {get;set;}
        //TreeView data list created from TestDataList
        public List<TreeNodeData> TreeDataList {get;set;}
        public MainViewModel()
        {
            //Flat Test Data List
            TestDataList = new List<Test>()
            {
                new Test(){Major = 1, Minor = 1},
                new Test(){Major = 1, Minor = 2},
                new Test(){Major = 1, Minor = 3},
                new Test(){Major = 1, Minor = 4},
                new Test(){Major = 2, Minor = 1},
                new Test(){Major = 2, Minor = 2},
                new Test(){Major = 2, Minor = 3},
            };

            //Tree Data List created from Test Data List
            TreeDataList = new List<TreeNodeData>();
            var majorList = (from t in TestDataList
                            select t.Major).Distinct().ToList();
            foreach(var major in majorList)
            {
                //test list with same Major revision
                var childTestList = from t in TestDataList
                                where t.Major == major
                                orderby t.Minor
                                select t;
                //Add child nodes
                List<TreeNodeData> childNodeList = new List<TreeNodeData>();
                foreach(var t in childTestList)
                {
                    childNodeList.Add(new TreeNodeData()
                    {
                        NodeName = $"Test {t.Major}.{t.Minor}",
                        IsTop = false,
                        IsSelected = false,
                    });
                }
                //Add top node
                TreeDataList.Add(new TreeNodeData()
                {
                    NodeName = $"Test {major}", 
                    ChildNodes = childNodeList,
                    IsTop = true,
                    IsSelected = false,
                });
            }
        }


        private string GetSelectedNodeNames(TreeNodeData tnd)
        {
            if(tnd.IsTop && tnd.ChildNodes!=null)
            {
                //Top Node, get all child node names if it have
                string selectedNodeNames = "";
                foreach(TreeNodeData nd in tnd.ChildNodes)
                {
                    selectedNodeNames += GetSelectedNodeNames(nd);
                }
                return selectedNodeNames;
            }
            else
            {
                //Child node, return Node name if it is selected.
                if(tnd.IsSelected)
                {
                    if(!string.IsNullOrEmpty(tnd.NodeName))
                        return tnd.NodeName+"\n";
                    else
                        return "";
                }
            }
            return "";
        }

        //ICommand for Start Button
        [RelayCommand]
        public void StartTesting()
        {
            string msg="";
            foreach(TreeNodeData tnd in TreeDataList)
            {
                msg += GetSelectedNodeNames(tnd);
            }
            if(!string.IsNullOrEmpty(msg))
            {
                MessageBox.Show(msg); 
            }
        }


        //ICommand for Back Button
        [RelayCommand]
        public void GoBack()
        {
            foreach(TreeNodeData tnd in TreeDataList)
            {
                //Check top node so that all child node will be unchecked by below statement
                tnd.IsSelected=true;
                //Top Node unchecked from Check state and will clear all child nodes to be unchecked
                tnd.IsSelected=false;
            }
        }
    }
}