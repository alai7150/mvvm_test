﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using mvvm.ViewModel;
using mvvm.Model;

namespace mvvm.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainViewModel();
        }

        public bool HasChildNodesChecked()
        {
            foreach(TreeNodeData tnd in MainTreeView.Items)
            {
                if(tnd.IsTop && tnd.ChildNodes != null)
                {
                    foreach(TreeNodeData nd in tnd.ChildNodes)
                    {
                        if(nd.IsSelected)
                            return true;
                    }
                }
                else
                {
                    if(tnd.IsSelected)
                        return true;
                }
            }
            return false;
        }

        private void CheckBox_CheckedChanged(object sender, RoutedEventArgs e)
        {
            if(sender!=null)
            {
                CheckBox cb = (CheckBox)sender;
                if(cb.IsThreeState)
                {
                    //Top Node
                    string nodeName = ((TextBlock)(((StackPanel)cb.Parent).Children[1])).Text;
                    TreeNodeData topNode = null;
                    //Go through top treeview nodes and find the with same nodeName
                    foreach(TreeNodeData nd in MainTreeView.Items)
                    {
                        if(nd.NodeName == nodeName)
                        {
                            topNode = nd;
                            break;
                        }
                    }
                    if(cb.IsChecked.HasValue && topNode != null)
                    {
                        if(cb.IsChecked.Value)
                        {
                            foreach(TreeNodeData childNode in topNode.ChildNodes)
                            {
                                childNode.IsSelected = true;
                            }
                        }
                        else
                        {
                            foreach(TreeNodeData childNode in topNode.ChildNodes)
                            {
                                childNode.IsSelected = false;
                            }
                        }
                    }
                }
                else
                {
                    //Child Node, 
                }

                BackButton.IsEnabled = StartButton.IsEnabled = HasChildNodesChecked();
            }
        }

        private void CollapseButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in MainTreeView.Items)
            {
                DependencyObject dObject = MainTreeView.ItemContainerGenerator.ContainerFromItem(item);
                CollapseTreeviewItems(((TreeViewItem)dObject));
            }
        }

        private void ExpandButton_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in MainTreeView.Items)
            {
                DependencyObject dObject = MainTreeView.ItemContainerGenerator.ContainerFromItem(item);
                ((TreeViewItem)dObject).ExpandSubtree();
            }
        }

        private void CollapseTreeviewItems(TreeViewItem Item)
        {
            Item.IsExpanded = false;
            foreach (var item in Item.Items)
            {
                DependencyObject dObject = Item.ItemContainerGenerator.ContainerFromItem(item);
                if (dObject != null)
                {
                    ((TreeViewItem)dObject).IsExpanded = false;
                    if (((TreeViewItem)dObject).HasItems)
                    {
                    CollapseTreeviewItems(((TreeViewItem)dObject));
                    }
                }
            }
        }

    }
}
